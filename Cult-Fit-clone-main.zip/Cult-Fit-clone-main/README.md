<h1>Cult-Fit-clone</h1>

_A fitness movement that is worth breaking a sweat for_
<!-- <hr> -->

<h3> About </h3>

At cult.fit, we strive to keep you fit & healthy through a range of servises that includes fitness and yoga, healthy meals, mental wellbeing and primary health care. Become healthy from the safety of your homes with cult fit that helps you to #BeBetterEveryDay #WeAreCult 

> In this project we have tried to clone frontend of cult.fit. Cart functionality has been added using browser's localstorage. Project design is responsive for all screen sizes. This project is an effort to implement learning at masai and improve our understanding of the web world.  Through this website we are trying to influence life style of people by providing assistance in improving there physical and mental health. Our fitness and eat page will give help to keep you fit and care and mind page will help with mental and primary health care.
<h3> Deployment link </h3>

<a href="https://charming-kleicha-f7531f.netlify.app/" target="_blank">https://charming-kleicha-f7531f.netlify.app/
 
<hr>
<h3> Tech Stack </h3>
 
 
<ol>
 <li>HTML</li> 
 <li>CSS</li> 
 <li>Bootstrap</li> 
 <li>JavaScript</li> 
</ol>

 <hr>
 
 <h3>Features</h3>
 
 1. Engaging, interactive and resposive design.
 2. Order food at confort of your home.
 3. Get best sessin for overall health improvement.

 <hr>
 
 <h3> Product Flow </h3>
 
 <h4> Landing Page <h4>

 ![1](https://user-images.githubusercontent.com/78145877/162580493-c365610d-9125-4368-9fec-fbb4034aad3a.png)

  <p>This is the landing page of our best which is high engaging.</P>
  
  <ul>
   <li>Navbar icons will take you to different section of the website</li>
   <li>Form location you can select the location where are servises are available</li>
   <li>User can login using a mobile number and an OTP</li>
   <li>Cart section will the item that are present in the cart</li>
  </ul>
  
  <h4> Cult </h4>
  
  This page provided you with cult coupons and personalised training
  
  <h4> Live  </h4>
  
  From here you can access live sessions with professional trainers. A variety of books have been provided here for better understanding of your body and mind.
  
  <h4> Mind </h4>
  
  This section takes care of your mind. Form here you can book session with professional psychiatrist
  
  <h4> Eat </h4>
  
  ![2](https://user-images.githubusercontent.com/78145877/162580996-f9f5ec8f-1a36-419c-8668-31dbcb94d9e8.png)
  
  <ol>
   <li>Order</li>
    <ul>
     <li>This page gives you insight on variety of food available to you for every meal of the day</li>
    </ul>
   <li>Meal Plans</li>
    <ul>
     <li>Food can be bought from here. Click of "add" button and item will be added to cart. If you are a vegetarian click on "veg" button to get the same.</li>
    </ul>
  </ol>
  
  <h4> Store </h4>
  
  This is our fintess store. This bring sports wear and fitness equipments.
  
  <h4> Checkout </h4>
  
  ![3](https://user-images.githubusercontent.com/78145877/162580897-70b79d6d-9287-4068-9041-7ebb9ebe10bf.png)
  
  > Items in the cart will be visible here. Quantity of item can be changed and item can also be removed. Fill your address and click on "Pay Now". This will open a pop-up to select method of payment. let's select credit/debit card. 
  
  
  <h4> Payment </h4>
  
  ![4](https://user-images.githubusercontent.com/78145877/162580901-7980c6e8-71b8-4e67-87a1-98ec9f88b43b.png)

  > This page will appear. Fill in the correct details and a pop up will show that order is placed. 
  
  
 <h3>Contributers </h3>
 <ol>
  
<!--   <a href="www.linkedin.com/in/tapish23"> LinkedIn </a> </li> -->
<!--   https://github.com/kakashi10-23 -->
<!--   <li>Tapish Sharma: <a href="https://github.com/kakashi10-23"> Github </a>  <a href="www.linkedin.com/in/tapish23"> LinkedIn </a> </li> -->
  
  <li>Tapish Sharma: https://github.com/kakashi10-23 </li>
  
  <li>Akshit Rana:  https://github.com/Akshit3010 </li>
   
  <li>Aman Raj: https://github.com/ROY-AMAN </li>
   
  <li>Pratik Jawanjal: https://github.com/kakashi10-23 </li>
   
  <li>Ankit Sangwan: https://github.com/AnkitSangwan8282 </li>
   
  <li>Gopi Reddy:  https://github.com/GopiReddy1708 </li>

 </ol>

