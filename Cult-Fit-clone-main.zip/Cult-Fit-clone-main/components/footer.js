const footer =() =>{
    return `
    <div id="footer">
        <div id="container1">
            <div id="c1d1">
                <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,w_150,ar_3.87,q_auto:eco,dpr_2,f_auto,fl_progressive//image/test/brand-logo/vman-and-white-cult-text.png" alt="" id="flogo"><br>
                <p class="c1d1p">At cult.fit,we make a group workouts fun,daily food healthy & tasty,mental fitness easy with yoga & menditation, Medical & lifestyle care hasslegree.#BeBetterEveryDay</p>
            </div>
            <div id="c1d2">
                <div>
                    <a href="" class="footera">cult.fit for business</a><br><br><br><br>
                    <a href="" class="footera">cult.fit franchies</a><br><br><br><br>
                    <a href="" class="footera">corporate partnerships</a><br><br><br><br>
                    <a href="" class="footera">cult pass network</a>
                </div>
                <div>
                    <a href="" class="footera">partner.fit</a><br><br><br><br>
                    <a href="" class="footera">blogs</a><br><br><br><br>
                    <a href="" class="footera">security</a><br><br><br><br>
                    <a href="" class="footera">careers</a>
                </div>
                <div class="c1d2d1">
                    <a href="" class="footera">contact us</a><br><br><br><br>
                    <a href="" class="footera">privacy policy</a><br><br><br><br>
                    <a href="" class="footera">refund policy</a><br><br><br><br>
                    <a href="" class="footera">terms & conditions</a>
                </div>
            </div>
            <div id="c1d3">
                <a href="https://apps.apple.com/us/app/cure-fit/id1217794588" target="_blank">
                    <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/app-store.png" alt="" class="c1d3i">
                </a><br><br>
                <a href="https://play.google.com/store/apps/details?id=fit.cure.android" target="_blank">
                    <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/google-play.png" alt="" class="c1d3i">
                </a><br><br>
                <div id="c1inner2">
                    <a href="https://www.youtube.com/channel/UCSE72IaHOL-1Tv-m3JHE4Cg" target="_blank">
                        <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/youtube.svg" alt="">
                    </a><br>
                    <a href="https://www.facebook.com/cultfitofficial" target="_blank">
                        <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/fb-page.svg" alt="">
                    </a><br>
                    <a href="https://twitter.com/cultfitOfficial" target="_blank">
                        <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/twitter-page.svg" alt="">
                    </a><br>
                    <a href="https://www.instagram.com/cultfitOfficial/" target="_blank">
                        <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/insta-page.svg" alt="">
                    </a><br>
                    <a href="https://www.linkedin.com/company/cult.fit/" target="_blank">
                        <img src="https://cdn-images.cure.fit/www-curefit-com/image/upload/c_fill,q_auto:eco,dpr_2,f_auto,fl_progressive//image/footer-web/FooterV3/linked-in-page.svg" alt="">
                    </a><br>
                </div>
            </div>
        </div>
        <div id="container2">
            <p>Related Searches</p>
            <div id="container2inner">
                <div>
                    <a href="" class="footera">Gym Near Me</a><br>
                    <a href="" class="footera">Consult Nutritionsist Online</a><br>
                    <a href="" class="footera">Exercise To Reduce Belly Fat </a><br>
                    <a href="" class="footera">Meditation Music</a><br>
                    <a href="" class="footera">Dermatologist online</a><br>
                    <a href="" class="footera">Gyms in Chennai</a><br>
                    <a href="" class="footera">Gyms in Coimbatore</a><br>
                    <a href="" class="footera">Mobility Exerices</a><br>
                    <a href="" class="footera">Core Exerices</a><br>
                    <a href="" class="footera">Fitness Glossary</a><br>
                </div>
                <div>
                    <a href="" class="footera">Online Personal Training</a><br>
                    <a href="" class="footera">Consult Gynecologist Online</a><br>
                    <a href="" class="footera">Six Pach workouts</a><br>
                    <a href="" class="footera">Pranayama</a><br>
                    <a href="" class="footera">Orthopedist doctor near me</a><br>
                    <a href="" class="footera">Gyms in Jaipur</a><br>
                    <a href="" class="footera">Guys in Banglore</a><br>
                    <a href="" class="footera">Kids Exercises</a><br>
                    <a href="" class="footera">Butt Ecercises</a><br>
                    <a href="" class="footera">Morning Exerxise</a><br>
                </div>
                <div>
                    <a href="" class="footera">Online Doctor Consultation</a><br>
                    <a href="" class="footera">Diagnostic Tests</a><br>
                    <a href="" class="footera">Yofa Postures for Beginners</a><br>
                    <a href="" class="footera">Bedtime Stories for Kids</a><br>
                    <a href="" class="footera">Gyms in Mumbai</a><br>
                    <a href="" class="footera">Gyms in Kolkata</a><br>
                    <a href="" class="footera">Home Workouts</a><br>
                    <a href="" class="footera">Dance Exercies</a><br>
                    <a href="" class="footera">Arm Workout at Home</a><br>
                </div>
                <div>
                    <a href="" class="footera">Therapist Consultation</a><br>
                    <a href="" class="footera">Food Near Me</a><br>
                    <a href="" class="footera">Surya Namaskar for Beginners</a><br>
                    <a href="" class="footera">Meditations in Hindi</a><br>
                    <a href="" class="footera">Gyms in Delhi</a><br>
                    <a href="" class="footera">Gyms in Ahmedabad</a><br>
                    <a href="" class="footera">Belly Fat Loss Exerise</a><br>
                    <a href="" class="footera">How to Lose Weight</a><br>
                    <a href="" class="footera">Back Exerices ar Home</a><br>
                </div>
                <div>
                    <a href="" class="footera">Online Fitness Classes</a><br>
                    <a href="" class="footera">Healthy Recipes</a><br>
                    <a href="" class="footera">Yoga For Stress Relief</a><br>
                    <a href="" class="footera">Mindfulness Meditation</a><br>
                    <a href="" class="footera">Gyms in Pune</a><br>
                    <a href="" class="footera">Gyms in Chandigarh</a><br>
                    <a href="" class="footera">Weight Loss Exercise</a><br>
                    <a href="" class="footera">HIIT Workout</a><br>
                    <a href="" class="footera">Abs Workout at Home</a><br>
                </div>
                <div>
                    <a href="" class="footera">Consult Cardiologist Online</a><br>
                    <a href="" class="footera">Chest Exerices</a><br>
                    <a href="" class="footera">Yoga Asanas</a><br>
                    <a href="" class="footera">Yoga Nidra</a><br>
                    <a href="" class="footera">Gyms in Hyderabad</a><br>
                    <a href="" class="footera">Gyms in Indore</a><br>
                    <a href="" class="footera">Strength Training</a><br>
                    <a href="" class="footera">Exerises for Toned Body</a><br>
                    <a href="" class="footera">Thigh Exerises</a><br>
                </div>
            </div>
        </div>
    </div>`;
};

export default footer;